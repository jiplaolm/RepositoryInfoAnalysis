#' The rlist package
#'
#' @name rlist
#' @docType package
NULL
